<aside class="aside1">
	<h2 class="title creighton">Featured Case Studies</h2>

	<a href="#" class="box b1 aOffset2" title="View: The SHERPA Case Study">
		<h3 class="title creighton">Case Study One</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore...</p>
		<span class="b1Bottom">
			<span class="btn btn1">
				<span>View Case Study</span>
				<i></i>
			</span>
		</span>
	</a>

	<a href="#" class="box b1 aOffset3" title="View: The SHERPA Case Study">
		<h3 class="title creighton">Case Study One</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore...</p>
		<span class="b1Bottom">
			<span class="btn btn1">
				<span>View Case Study</span>
				<i></i>
			</span>
		</span>
	</a>
</aside>