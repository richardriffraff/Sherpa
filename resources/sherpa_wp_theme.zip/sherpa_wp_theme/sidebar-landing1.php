<a href="#" class="box b2 bOffset1" title="View: About The SHERPA Clinic">
	<h4 class="title creighton">Sherpa Clinic</h4>
	<p>Lorem ipsum dolor sit amet, adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore...</p>
	<span class="btn btn2">
		<span>Find Out More</span>
		<i></i>
	</span>
</a>

<div class="hr"><hr /></div>

<a href="#" class="box b3 aOffset1" title="View: About The SHERPA Catalyst">
	<h4 class="title creighton">The Sherpa Catalyst</h4>
	<p>Lorem ipsum dolor sit amet, adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore...</p>
	<span class="btn btn2">
		<span>Find Out More</span>
		<i></i>
	</span>
</a>

<blockquote class="blockQuote bQuote2 bQOffset1">
	<p>Something nice someone said about your service, particularly with regard to benefits and transparent, risk-free nature of the service</p>
	<cite>Mr George Stephenson, The Rocket</cite>
</blockquote>

<!-- END WP, sidebar-landing1.php -->