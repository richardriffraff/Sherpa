		<nav class="nav5">
			<h2 class="title creighton">Archives</h2>
			<ul>
				<?php wp_get_archives('type=monthly'); ?>
			</ul>
			<a href="#" title="Subscribe: SHERPA Business Consultancy Blog" class="rss">RSS</a>
		</nav>

		<div class="hr"><hr /></div>

		<nav class="nav5">
			<?php wp_list_categories("show_count=1&title_li=<h2 class='title creighton'>Categories</h2>"); ?>
		</nav>

		<div class="hr"><hr /></div>

		<nav class="nav5">
			<h2 class="title creighton">Meta</h2>
			<ul>
				<li><?php wp_register(); ?></li>
				<li><?php wp_loginout(); ?></li>
			</ul>
		</nav>