<nav class="nav3 nOffset1 clearfix">
	<h3 class="title creighton">Services <span>For Early Stage Business</span></h3>
	<ul>
		<li><a href="#" title="View: Link Title">Define Sales, Operations &amp; Financial Process</a></li>
		<li><a href="#" title="View: Link Title">Management Team Development through Coaching &amp; Mentorship</a></li>
		<li><a href="#" title="View: Link Title">Managing Growth through processes, delegation &amp; Leadership</a></li>
		<li><a href="#" title="View: Link Title">Non-exec board-level support</a></li>
		<li><a href="#" title="View: Link Title">Planning and Reporting</a></li>
	</ul>
</nav>

<div class="hr"><hr /></div>

<a href="#" class="box b2 aOffset1" title="View: About The SHERPA Clinic">
	<h4 class="title creighton">Sherpa Clinic</h4>
	<p>Lorem ipsum dolor sit amet, adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore...</p>
	<span class="btn btn2">
		<span>Find Out More</span>
		<i></i>
	</span>
</a>

<div class="hr"><hr /></div>

<a href="#" class="box b3 aOffset1" title="View: About The SHERPA Catalyst">
	<h4 class="title creighton">The Sherpa Catalyst</h4>
	<p>Lorem ipsum dolor sit amet, adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore...</p>
	<span class="btn btn2">
		<span>Find Out More</span>
		<i></i>
	</span>
</a>

<!-- END WP, sidebar-services.php -->